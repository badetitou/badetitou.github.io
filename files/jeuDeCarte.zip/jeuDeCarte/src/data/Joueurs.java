package data;

import game.Jeu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Joueurs {
    int vie;
    List<Carte> main;
    List<Carte> deck;
    Terrain terrain;
    Joueurs adverse;

    public Joueurs(){
        vie = 40;
    }

    public Joueurs(int nbCarte){
        vie = 40;
        main = new ArrayList<>();
        deck = new ArrayList<>();
        terrain = new Terrain();
        for (int i = 0; i< nbCarte/2;++i){
            deck.add(new CarteMagique(randomWithRange(5,10)));
            deck.add(new CarteMonstre(randomWithRange(5,10)));
        }
    }

    private int randomWithRange(int min, int max)
    {
        int range = (max - min) + 1;
        return (int)(Math.random() * range) + min;
    }

    public void setAdverse(Joueurs adverse) {
        this.adverse = adverse;
    }

    public int getVie() {
        return vie;
    }

    public void pioche(){
        main.add(deck.remove(0));
    }

    public void joueTour() {
        pioche();
        joueCarte();
        attaqueTerrain();
    }

    private void attaqueTerrain() {
        terrain.joue(adverse);
    }

    private void joueCarte() {
        Carte c = demandeCarteAJouer();
        c.jouer(adverse, terrain);
        main.remove(c);

    }

    private Carte demandeCarteAJouer() {
        for (int i = 0;i<main.size();++i){
            System.out.println(i +  " " + main.get(i));
        }
        System.out.println("Entre le numero de la carte que tu veux jouer");
        Scanner sc = new Scanner(System.in);
        return main.get(sc.nextInt());
    }

    public void inflige(int degat) {
        vie = vie - degat;
    }
}
