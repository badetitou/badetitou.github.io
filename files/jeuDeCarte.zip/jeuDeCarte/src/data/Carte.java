package data;

public abstract class Carte {
    int degat;

    public abstract void jouer(Joueurs adverse, Terrain terrain);

    public void attaque(Joueurs adverse) {
        adverse.inflige(degat);
    }

    public Carte(int degat){
        this.degat = degat;
    }

    @Override
    public String toString() {
        return "degats: " + degat;
    }
}
