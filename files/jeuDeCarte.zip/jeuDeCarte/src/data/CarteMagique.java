package data;

public class CarteMagique extends Carte {

    public CarteMagique(int degat) {
        super(degat);
    }

    @Override
    public void jouer(Joueurs adverse, Terrain terrain) {
        this.attaque(adverse);
    }
}
