package data;

public class CarteMonstre extends Carte {
    @Override
    public void jouer(Joueurs adverse, Terrain terrain) {
        terrain.poseCarte(this);
    }

    public CarteMonstre(int degat) {
        super(degat);
    }
}
