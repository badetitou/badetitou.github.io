package data;

import java.util.ArrayList;
import java.util.List;

public class Terrain {
    List<CarteMonstre> cartesPose;

    public Terrain (){
        cartesPose = new ArrayList<>();
    }


    public void poseCarte(CarteMonstre carteMonstre) {
        cartesPose.add(carteMonstre);
    }

    public void joue(Joueurs adverse) {
        for(CarteMonstre cm : cartesPose){
            cm.attaque(adverse);
        }
    }
}
