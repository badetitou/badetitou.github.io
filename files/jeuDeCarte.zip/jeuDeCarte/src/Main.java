import data.Joueurs;
import game.Jeu;

public class Main {

    public static void main(String[] args){
        Joueurs j1 = new Joueurs(40);
        Joueurs j2 = new Joueurs(40);

        Jeu j = new Jeu(j1, j2);
        j.jouer();
    }
}
