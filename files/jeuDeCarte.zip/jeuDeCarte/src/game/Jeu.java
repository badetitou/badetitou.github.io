package game;

import data.Joueurs;

public class Jeu {
    Joueurs j1;
    Joueurs j2;

    public Jeu(Joueurs j1, Joueurs j2){
        this.j1 = j1;
        this.j2 = j2;
        j1.setAdverse(j2);
        j2.setAdverse(j1);
    }

    public void jouer() {
        initPartie();
        Joueurs courant = j1;
        while(courant.getVie() > 0){
            courant.joueTour();
            if(courant == j1){
                courant = j2;
            } else {
                courant = j1;
            }
        }
    }

    private void initPartie() {
        for (int i = 0;i<7;++i){
            j1.pioche();
            j2.pioche();
        }
    }
}
